import os
import requests


class MarketClient:
    FUTGG_URL = "https://www.fut.gg/api/fut/players/v2/27/"
    PARSE_URL = (
        "https://api.parse.bot/scraper/"
        "21963078-8a17-40ff-a896-9b0b0ec3e828/"
        "get_fc27_market_snapshot"
    )

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://www.fut.gg/players/momentum/",
        })
        self.parse_key = os.getenv("MARKET_API_KEY", "").strip()

    def get_momentum_ids(self):
        params = {
            "hours": "6",
            "page": 1,
            "onlySpecialCards": "true",
            "price__gte": 300000,
        }

        print("========== FUT.GG MOMENTUM 6H ==========")
        response = self.session.get(self.FUTGG_URL, params=params, timeout=30)
        print("FUT.GG HTTP:", response.status_code)
        response.raise_for_status()
        data = response.json()

        players = None
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, list) and value:
                    players = value
                    print("Lista trovata in:", key)
                    break

        if not players:
            print("Nessuna carta trovata.")
            return []

        ids = []
        for player in players:
            if not isinstance(player, dict):
                continue
            player_id = player.get("id") or player.get("player_id") or player.get("ea_id")
            if player_id is not None:
                try:
                    ids.append(int(player_id))
                except (TypeError, ValueError):
                    pass

        ids = list(dict.fromkeys(ids))
        print("Carte ricevute:", len(players))
        print("ID Momentum trovati:", len(ids))
        return ids

    def get_parse_prices(self, player_ids):
        if not self.parse_key:
            print("MARKET_API_KEY non configurata: salto Parse.")
            return []
        if not player_ids:
            return []

        response = self.session.get(
            self.PARSE_URL,
            headers={"X-API-Key": self.parse_key},
            params={"player_ids": ",".join(map(str, player_ids))},
            timeout=30,
        )
        print("Parse HTTP:", response.status_code)

        if not response.ok:
            print("Parse error:", response.text[:1000])
            return []

        payload = response.json()
        data = payload.get("data", {}) if isinstance(payload, dict) else {}
        players = data.get("players", []) if isinstance(data, dict) else []

        print(f"Prezzi Parse ricevuti: {len(players)}/{len(player_ids)}")
        for player in players:
            print(f"ID {player.get('player_id')} -> {player.get('price')} coins")
        return players

    def get_cards(self, ids=None, platform="ps"):
        # Fase attuale: FUT.GG pagina 1 -> 30 ID -> una sola richiesta batch a Parse.
        # Non genera ancora alert finché non definiamo il riferimento 6h corretto.
        momentum_ids = self.get_momentum_ids()
        self.get_parse_prices(momentum_ids)
        return []
