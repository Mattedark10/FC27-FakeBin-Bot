# FC27 Momentum Monitor - GitHub Actions

Versione GitHub Actions del monitor FC27.

## Stato attuale

- Legge FUT.GG Momentum 6h, pagina 1.
- Solo special cards.
- Filtro FUT.GG minimo 300.000 coins.
- Estrae circa 30 ID dalla pagina 1.
- Può inviare tutti gli ID a Parse in una singola richiesta batch.
- Non manda ancora alert di prezzo: prima va definito correttamente il prezzo/riferimento 6h.

## Importante: Parse

Hai terminato i crediti Parse. Per questo il workflow è impostato **solo manuale** (`workflow_dispatch`) e lo schedule automatico è commentato, così non consuma crediti accidentalmente.

Se `MARKET_API_KEY` non è configurata, il programma controlla FUT.GG ma salta Parse.

## Come caricarlo su GitHub

1. Estrai lo ZIP.
2. Carica tutti i file nella root del repository, inclusa la cartella `.github/workflows/`.
3. In GitHub vai in **Settings > Secrets and variables > Actions**.
4. Aggiungi `MARKET_API_KEY` quando avrai nuovamente accesso a Parse.
5. In **Actions > FC27 Momentum Monitor > Run workflow** puoi avviare un test manuale.

## Esecuzione automatica

GitHub Actions non è adatto a un controllo garantito ogni 60 secondi. Il cron minimo pratico è 5 minuti e può subire ritardi. Quando il monitor sarà completo, puoi togliere i `#` dalle righe `schedule` nel workflow per abilitarlo ogni 5 minuti.
