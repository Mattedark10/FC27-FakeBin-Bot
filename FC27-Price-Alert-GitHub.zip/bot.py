import logging
from dotenv import load_dotenv

load_dotenv()

from market import MarketClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("fc27-alert")


def run_once():
    try:
        client = MarketClient()
        client.get_cards(platform="ps")
    except Exception:
        log.exception("Errore durante il controllo")
        raise


if __name__ == "__main__":
    run_once()
