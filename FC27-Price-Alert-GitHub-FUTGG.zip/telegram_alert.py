import os, requests
class TelegramAlert:
    def __init__(self):
        self.token=os.getenv("TELEGRAM_BOT_TOKEN","").strip()
        self.chat_id=os.getenv("TELEGRAM_CHAT_ID","").strip()
        if not self.token or not self.chat_id:
            raise RuntimeError("Configura TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID nel file .env")
    def send(self,text):
        r=requests.post(f"https://api.telegram.org/bot{self.token}/sendMessage",
            json={"chat_id":self.chat_id,"text":text,"parse_mode":"HTML"},timeout=20)
        r.raise_for_status()
